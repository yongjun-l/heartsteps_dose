## ----knit-setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
collapse = TRUE,
comment = "#>"
)

## -----------------------------------------------------------------------------
library(mrt.dose)
m=5; n=30; time=2; days=2; eta=c(1,2,3,4); rho=0; theta1=c(3,2,1); theta2=0; beta10=1; beta11=0; beta12=0; p=0.5; dose=1
dfs <- simMhealth(m, n, time, days, eta, rho, theta1, theta2, beta10, beta11, beta12, p)
head(round(dfs[[1]],3),8)

## -----------------------------------------------------------------------------
#debugonce(mHealthDose)
fit <- mHealthDose(dfs[[1]], id="ID", day="DAY", slot="SLOT", p,
                   dose=dose, y="Y", trt="A",
                   baseline=c("H1", "H2"), timevar=c("S1", "S2"),
                   b.prime=c("H1", "H2"), t.prime=c("S1", "S2"),
                   boot = m, cores = 1, print_progress=FALSE)

## -----------------------------------------------------------------------------
print(fit)

## -----------------------------------------------------------------------------
coef(fit)
coef(fit, param=c("A1", "A1:H2"))

## -----------------------------------------------------------------------------
confint(fit)
confint(fit, param=c("A1", "A1:H2"), level=0.9)

## -----------------------------------------------------------------------------
pval(fit)
pval(fit, param=c("A1", "A1:H2"))

## -----------------------------------------------------------------------------
summary(fit)

## -----------------------------------------------------------------------------
m=5; boot=5; n=10; time=5; days=2; eta=c(3,2,1,4); rho=0.5; theta1=c(3,2,1); theta2=0; 
beta10=1; beta11=0.5; beta12=0.3; p=0.5; dose=1
dfs <- simMhealth(m, n, time, days, eta, rho, theta1, theta2, beta10, beta11, beta12, p)
mHealthDose(dfs, id="ID", day="DAY", slot="SLOT", p,
            dose=dose, y="Y", trt="A",
            baseline=c("H1", "H2"), timevar=c("S1", "S2"),
            b.prime=c("H1"), t.prime=c("S1"),
            boot = boot, cores = 1, sim = TRUE, print_progress=FALSE)

## ----setup--------------------------------------------------------------------
m=5; n=300; time=5; days=10; eta=c(3,2,1,4); rho=0.5; theta1=c(3,2,1); theta2=0; 
beta10=5; beta11=c(3,2); beta12=c(2,1); p=0.5; dose=1
dfs <- simMhealth(m, n, time, days, eta, rho, theta1, theta2, beta10, beta11, beta12, p)
fits <- mHealthDoses(dfs, id="ID", day="DAY", slot="SLOT", p,
                     doses=c(1,2,3,4,5), y="Y", trt="A",
                     baseline=c("H1", "H2"), timevar=c("S1", "S2"),
                     b.prime=c("H1", "H2"), t.prime=c("S1", "S2"),
                     boot = m, cores = 1, sim = TRUE)
summary(fits)

## ----fig.width=7, fig.height=5, fig.align='center'----------------------------
sum <- summary(fits)
varlevels <- rbind(H1 = c("Male", "Female"), 
                   S1 = c("Student", "Non-student"), 
                   H2 = c("Mean Age", "Mean Age+1"), 
                   S2 = c("Physical Low", "Physical High"))
colnames(varlevels) <- c("Main Effect", "Interaction Effect")
p <- plot(sum, varlevels)

## ----fig.width=5, fig.height=3, fig.align='center'----------------------------
p[["H1"]]

